import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';

const firebaseConfig = {
  apiKey: "AIzaSyD2jKFMjuy462JPxOJ8vOk0DJtmUyAqNvc",
  authDomain: "masartamayoz-682af.firebaseapp.com",
  projectId: "masartamayoz-682af",
  storageBucket: "masartamayoz-682af.appspot.com",
  messagingSenderId: "527464088229",
  appId: "1:527464088229:web:2575dd046f6379f8c5034c"
};

const app = initializeApp(firebaseConfig);
export default app;