import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js';
import { getFirestore, doc, getDoc, collection, getDocs, query, where } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-storage.js';
import Chart from 'https://cdn.jsdelivr.net/npm/chart.js';

const auth = getAuth();
const db = getFirestore();
const storage = getStorage();

const adminName = document.getElementById('adminName');
const adminEmail = document.getElementById('adminEmail');
const joinDate = document.getElementById('joinDate');
const usersChart = document.getElementById('usersChart').getContext('2d');
const userAvatar = document.getElementById('userAvatar');
const logoutBtn = document.getElementById('logoutBtn');
const scheduledLessons = document.getElementById('scheduledLessons');

let chart = new Chart(usersChart, {
  type: 'pie',
  data: { labels: ['الطلاب', 'المعلمون', 'الأولياء', 'المشرفون'], datasets: [{ data: [0, 0, 0, 0], backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'] }] },
  options: { responsive: true }
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists() && userDoc.data().userType === 'admin') {
      const userData = userDoc.data();
      adminName.textContent = userData.name || 'غير محدد';
      adminEmail.textContent = user.email || 'غير محدد';
      joinDate.textContent = userData.createdAt?.toDate().toLocaleDateString('ar-EG') || 'غير محدد';
      userAvatar.textContent = userData.name?.charAt(0) || user.email.charAt(0);

      const [students, teachers, parents, admins] = await Promise.all([
        getDocs(query(collection(db, 'users'), where('userType', '==', 'student'))),
        getDocs(query(collection(db, 'users'), where('userType', '==', 'teacher'))),
        getDocs(query(collection(db, 'users'), where('userType', '==', 'parent'))),
        getDocs(query(collection(db, 'users'), where('userType', '==', 'admin')))
      ]);
      chart.data.datasets[0].data = [students.size, teachers.size, parents.size, admins.size];
      chart.update();

      const lessons = await getDocs(collection(db, 'courses'));
      scheduledLessons.innerHTML = lessons.docs.map(doc => `<p>${doc.data().subject} - <a href="${doc.data().meetLink}" target="_blank">انضم</a></p>`).join('');
    } else window.location.href = '../index.html';
  } else window.location.href = '../login.html';
});

logoutBtn.addEventListener('click', () => signOut(auth).then(() => window.location.href = '../login.html'));