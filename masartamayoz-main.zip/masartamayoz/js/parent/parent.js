import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js';
import { getFirestore, doc, getDoc, collection, getDocs, query, where } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js';
import Chart from 'https://cdn.jsdelivr.net/npm/chart.js';

const auth = getAuth();
const db = getFirestore();

const parentName = document.getElementById('parentName');
const parentEmail = document.getElementById('parentEmail');
const childrenCount = document.getElementById('childrenCount');
const childrenGradesChart = document.getElementById('childrenGradesChart').getContext('2d');
const userAvatar = document.getElementById('userAvatar');
const logoutBtn = document.getElementById('logoutBtn');
const meetLinks = document.getElementById('meetLinks');

let chart = new Chart(childrenGradesChart, {
  type: 'bar',
  data: { labels: [], datasets: [{ label: 'متوسط الدرجات (%)', data: [], backgroundColor: 'rgba(75, 192, 192, 0.2)', borderColor: 'rgba(75, 192, 192, 1)', borderWidth: 1 }] },
  options: { scales: { y: { beginAtZero: true, max: 100 } } }
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists() && userDoc.data().userType === 'parent') {
      const userData = userDoc.data();
      parentName.textContent = userData.name || 'غير محدد';
      parentEmail.textContent = user.email || 'غير محدد';
      const children = userData.children || [];
      childrenCount.textContent = children.length;
      const grades = [];
      for (const childId of children) {
        const childDoc = await getDoc(doc(db, 'users', childId));
        if (childDoc.exists()) {
          const childGrades = childDoc.data().grades || {};
          grades.push(Object.values(childGrades).reduce((a, b) => a + b, 0) / Object.keys(childGrades).length || 0);
        }
      }
      chart.data.labels = children.map((_, i) => `ابن ${i + 1}`);
      chart.data.datasets[0].data = grades;
      chart.update();
      userAvatar.textContent = userData.name?.charAt(0) || user.email.charAt(0);

      const childLessons = await getDocs(query(collection(db, 'courses'), where('level', 'in', children.map(c => (await getDoc(doc(db, 'users', c))).data().level))));
      meetLinks.innerHTML = childLessons.docs.map(doc => `<p>${doc.data().subject} - <a href="${doc.data().meetLink}" target="_blank">انضم</a></p>`).join('');
    } else window.location.href = '../index.html';
  } else window.location.href = '../login.html';
});

logoutBtn.addEventListener('click', () => signOut(auth).then(() => window.location.href = '../login.html'));