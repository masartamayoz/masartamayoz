import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js';
import { getFirestore, collection, getDocs } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js';

const auth = getAuth();
const db = getFirestore();
const coursesList = document.getElementById('coursesList');
const userAvatar = document.getElementById('userAvatar');
const logoutBtn = document.getElementById('logoutBtn');

onAuthStateChanged(auth, async (user) => {
  if (user) {
    userAvatar.textContent = user.email.charAt(0).toUpperCase();
    const snapshot = await getDocs(collection(db, 'courses'));
    coursesList.innerHTML = snapshot.docs.map(doc => {
      const data = doc.data();
      return `
        <div class="col-md-4 mb-4">
          <div class="card text-center">
            <div class="card-body">
              <h5 class="card-title">${data.subject || 'دورة غير محددة'}</h5>
              <p class="card-text">المستوى: ${data.level || 'غير محدد'}</p>
              <a href="${data.meetLink}" class="btn btn-primary" target="_blank">انضم إلى الدرس</a>
            </div>
          </div>
        </div>
      `;
    }).join('');
  } else {
    userAvatar.textContent = '<i class="fas fa-user"></i>';
    coursesList.innerHTML = '<p>يرجى تسجيل الدخول لعرض الدورات.</p>';
  }
});

logoutBtn.addEventListener('click', () => signOut(auth).then(() => window.location.href = '../login.html'));