import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js';
import { getFirestore, doc, getDoc, collection, getDocs, query, where } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js';
import Chart from 'https://cdn.jsdelivr.net/npm/chart.js';

const auth = getAuth();
const db = getFirestore();

const studentName = document.getElementById('studentName');
const studentEmail = document.getElementById('studentEmail');
const courseCount = document.getElementById('courseCount');
const gradesChart = document.getElementById('gradesChart').getContext('2d');
const userAvatar = document.getElementById('userAvatar');
const logoutBtn = document.getElementById('logoutBtn');
const meetLink = document.getElementById('meetLink');
const contentList = document.getElementById('contentList');

let chart = new Chart(gradesChart, {
  type: 'bar',
  data: { labels: [], datasets: [{ label: 'الدرجات (%)', data: [], backgroundColor: 'rgba(54, 162, 235, 0.2)', borderColor: 'rgba(54, 162, 235, 1)', borderWidth: 1 }] },
  options: { scales: { y: { beginAtZero: true, max: 100 } } }
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists() && userDoc.data().userType === 'student') {
      const userData = userDoc.data();
      studentName.textContent = userData.name || 'غير محدد';
      studentEmail.textContent = user.email || 'غير محدد';
      const enrolledCourses = userData.enrolledCourses || [];
      const grades = userData.grades || {};
      courseCount.textContent = enrolledCourses.length;
      chart.data.labels = enrolledCourses;
      chart.data.datasets[0].data = enrolledCourses.map(c => grades[c] || 0);
      chart.update();
      userAvatar.textContent = userData.name?.charAt(0) || user.email.charAt(0);

      const q = query(collection(db, 'courses'), where('level', '==', userData.level));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) meetLink.innerHTML = `<a href="${snapshot.docs[0].data().meetLink}" target="_blank">انضم إلى الدرس</a>`;

      const content = await getDocs(collection(db, 'content'));
      contentList.innerHTML = content.docs.map(doc => {
        const data = doc.data();
        return `<p>${data.type}: <a href="${data.url}" target="_blank">${data.url}</a></p>`;
      }).join('');
    } else window.location.href = '../index.html';
  } else window.location.href = '../login.html';
});

logoutBtn.addEventListener('click', () => signOut(auth).then(() => window.location.href = '../login.html'));