import app from './firebase-config.js';
import {
  getAuth,
  onAuthStateChanged,
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js';

const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// ==================== دوال المساعدة ====================
const showToast = (message, type = 'info') => {
  console.log(`Showing toast: ${message}, type: ${type}`);
  const toastContainer = document.getElementById('toast-container') || document.body;
  if (!toastContainer) {
    console.error('Toast container not found in DOM');
    return;
  }
  const toastId = `toast-${Date.now()}`;
  const toast = document.createElement('div');
  toast.id = toastId;
  toast.className = `toast align-items-center text-bg-${type} border-0`;
  toast.setAttribute('role', 'alert');
  toast.setAttribute('aria-live', 'assertive');
  toast.setAttribute('aria-atomic', 'true');
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="إغلاق"></button>
    </div>
  `;
  toastContainer.appendChild(toast);
  const bootstrapToast = new bootstrap.Toast(toast, { delay: 5000 });
  bootstrapToast.show();
  toast.addEventListener('hidden.bs.toast', () => toast.remove());
};

const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
const validatePassword = (password) => password.length >= 8 && /[A-Zا-ي]/.test(password) && /[a-zا-ي]/.test(password) && /[0-9]/.test(password);

const populateSelect = (selectId, options, defaultOptionText) => {
  const select = document.getElementById(selectId);
  if (!select) {
    console.error(`Select element ${selectId} not found`);
    return;
  }
  select.innerHTML = '';
  const fragment = document.createDocumentFragment();
  if (defaultOptionText) {
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = defaultOptionText;
    fragment.appendChild(defaultOption);
  }
  options.forEach(optionValue => {
    const option = document.createElement('option');
    option.value = optionValue;
    option.textContent = optionValue;
    fragment.appendChild(option);
  });
  select.appendChild(fragment);
};

// دالة لتحميل بيانات المستخدم
const loadUserProfile = async (user) => {
  try {
    console.log('Loading user profile for UID:', user.uid);
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);
    
    if (userDoc.exists()) {
      const userData = userDoc.data();
      console.log('User data retrieved:', userData);
      
      const profileElements = {
        firstNameDisplay: document.getElementById('firstNameDisplay'),
        lastNameDisplay: document.getElementById('lastNameDisplay'),
        phoneDisplay: document.getElementById('phoneDisplay'),
        birthDateDisplay: document.getElementById('birthDateDisplay'),
        stateDisplay: document.getElementById('stateDisplay'),
        delegationDisplay: document.getElementById('delegationDisplay'),
        educationLevelDisplay: document.getElementById('educationLevelDisplay'),
        academicYearDisplay: document.getElementById('academicYearDisplay'),
        branchDisplay: document.getElementById('branchDisplay'),
        electiveSubjectDisplay: document.getElementById('electiveSubjectDisplay'),
        studentAverageDisplay: document.getElementById('studentAverageDisplay'),
        avatarPreview: document.getElementById('avatarPreview')
      };

      const editElements = {
        editFirstName: document.getElementById('editFirstName'),
        editLastName: document.getElementById('editLastName'),
        editPhone: document.getElementById('editPhone'),
        editBirthDate: document.getElementById('editBirthDate'),
        editState: document.getElementById('editState'),
        editDelegation: document.getElementById('editDelegation'),
        editStudentAverage: document.getElementById('editStudentAverage')
      };

      // تعيين القيم في عناصر العرض
      Object.keys(profileElements).forEach(key => {
        if (profileElements[key]) {
          const fieldName = key.replace('Display', '').toLowerCase();
          if (fieldName === 'avatarPreview') {
            profileElements[key].src = userData.avatarUrl || '../assets/default-avatar.png';
          } else if (fieldName === 'birthDate' && userData[fieldName]) {
            profileElements[key].textContent = new Date(userData[fieldName]).toLocaleDateString('ar-TN', { day: '2-digit', month: '2-digit', year: 'numeric' }) || 'غير محدد';
          } else {
            profileElements[key].textContent = userData[fieldName] || 'غير محدد';
          }
        } else {
          console.warn(`Display element for ${key} not found`);
        }
      });

      // تعيين القيم في حقول الإدخال
      Object.keys(editElements).forEach(key => {
        if (editElements[key]) {
          const fieldName = key.replace('edit', '').toLowerCase();
          editElements[key].value = userData[fieldName] || '';
        }
      });

      // تحديث قائمة المعتمديات بناءً على الولاية
      if (userData.state && editElements.editState && editElements.editDelegation) {
        const cachedWilayas = JSON.parse(localStorage.getItem('wilayas') || '{}');
        if (cachedWilayas[userData.state]) {
          populateSelect('editDelegation', cachedWilayas[userData.state], 'اختر المعتمدية');
          editElements.editDelegation.value = userData.delegation || '';
        }
      }
    } else {
      console.warn('User document does not exist for UID:', user.uid);
      showToast('لم يتم العثور على بيانات المستخدم', 'warning');
      
      // تعيين القيم الافتراضية
      const fields = [
        'firstName', 'lastName', 'phone', 'birthDate', 'state', 'delegation',
        'studentAverage', 'educationLevel', 'academicYear', 'branch', 'electiveSubject'
      ];
      fields.forEach(field => {
        const displayElement = document.getElementById(`${field}Display`);
        const inputElement = document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}`);
        if (displayElement) {
          displayElement.textContent = 'غير محدد';
        }
        if (inputElement) {
          inputElement.value = '';
        }
      });
      const avatarPreview = document.getElementById('avatarPreview');
      if (avatarPreview) {
        avatarPreview.src = '../assets/default-avatar.png';
      }
    }
  } catch (error) {
    console.error('Error fetching user profile:', error);
    const errorMessages = {
      'permission-denied': 'ليس لديك إذن للوصول إلى البيانات',
      'unavailable': 'خدمة Firestore غير متاحة، تحقق من اتصالك بالإنترنت',
      'unauthenticated': 'يرجى تسجيل الدخول مرة أخرى'
    };
    showToast(errorMessages[error.code] || `خطأ أثناء تحميل الملف الشخصي: ${error.code} - ${error.message}`, 'danger');
    if (error.code === 'unauthenticated') {
      setTimeout(() => window.location.href = '../pages/login.html', 1500);
    }
  }
};

// دالة لتوجيه المستخدم بناءً على نوعه
const redirectUserBasedOnType = async (user) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    const currentPath = window.location.pathname;
    if (userDoc.exists()) {
      const userData = userDoc.data();
      const userType = userData.userType || 'parent';
      if (!currentPath.includes('login.html') && !currentPath.includes('register.html') && !currentPath.includes('change-password.html') && !currentPath.includes('edit-profile')) {
        switch (userType) {
          case 'student':
            if (!currentPath.includes('student-dashboard.html')) window.location.href = '../pages/student-dashboard.html';
            break;
          case 'parent':
            if (!currentPath.includes('parent-dashboard.html')) window.location.href = '../pages/parent-dashboard.html';
            break;
          case 'teacher':
            if (!currentPath.includes('teacher-dashboard.html')) window.location.href = '../pages/teacher-dashboard.html';
            break;
          default:
            if (!currentPath.includes('index.html')) window.location.href = '../pages/index.html';
        }
      }
    } else {
      if (!currentPath.includes('index.html')) window.location.href = '../pages/index.html';
    }
  } catch (error) {
    console.error('Error redirecting user:', error);
    showToast('خطأ أثناء توجيه المستخدم', 'danger');
  }
};

// ==================== إدارة حالة المصادقة ====================
onAuthStateChanged(auth, async (user) => {
  const userOptions = document.querySelector('.user-options');
  const authLinks = document.querySelectorAll('[data-auth]');
  
  if (user) {
    console.log('User authenticated:', user.uid);
    localStorage.setItem('userLoggedIn', 'true');
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    let userType = 'parent';
    if (userDoc.exists()) {
      userType = userDoc.data().userType || 'parent';
      console.log('User type:', userType);
    }

    if (userOptions) {
      userOptions.innerHTML = `
        <a href="#" class="user-option" id="dashboardLink"><i class="fas fa-tachometer-alt"></i> لوحة التحكم</a>
        <a href="#" class="user-option logout-link"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
      `;
      
      const dashboardLink = document.getElementById('dashboardLink');
      if (dashboardLink) {
        dashboardLink.href = userType === 'student' ? '../pages/student-dashboard.html' :
                           userType === 'parent' ? '../pages/parent-dashboard.html' :
                           userType === 'teacher' ? '../pages/teacher-dashboard.html' : '../pages/index.html';
        dashboardLink.addEventListener('click', (e) => {
          e.preventDefault();
          redirectUserBasedOnType(user);
        });
      }

      document.querySelectorAll('.logout-link, #logoutBtn').forEach(link => {
        link.addEventListener('click', (e) => {
          e.preventDefault();
          console.log('Logout clicked');
          logout();
        });
      });
    }
    
    authLinks.forEach(link => {
      link.style.display = link.getAttribute('data-auth') === 'logged-in' ? 'block' : 'none';
    });
    
    if (!user.emailVerified && !window.location.pathname.includes('login.html') && !window.location.pathname.includes('register.html')) {
      await sendEmailVerification(user);
      showToast('تم إرسال رابط التحقق إلى بريدك الإلكتروني', 'warning');
    }

    const currentPath = window.location.pathname;
    const profilePages = ['student-dashboard.html', 'parent-dashboard.html', 'teacher-dashboard.html', 'edit-profile'];
    if (profilePages.some(page => currentPath.includes(page))) {
      console.log('Loading user profile for:', currentPath);
      await loadUserProfile(user).catch(error => console.error('Failed to load profile:', error));
    }

    if (!currentPath.includes('login.html') && !currentPath.includes('register.html') && !currentPath.includes('change-password.html')) {
      await redirectUserBasedOnType(user);
    }
  } else {
    console.log('No user logged in');
    localStorage.removeItem('userLoggedIn');
    if (userOptions) {
      userOptions.innerHTML = `
        <a href="../pages/login.html" class="user-option"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</a>
        <a href="../pages/register.html" class="user-option"><i class="fas fa-user-plus"></i> إنشاء حساب</a>
      `;
    }
    
    authLinks.forEach(link => {
      link.style.display = link.getAttribute('data-auth') === 'logged-out' ? 'block' : 'none';
    });

    setTimeout(() => {
      const justLoggedOut = localStorage.getItem('justLoggedOut');
      if (justLoggedOut) {
        localStorage.removeItem('justLoggedOut');
      } else if (window.location.pathname.includes('student-dashboard.html') || window.location.pathname.includes('parent-dashboard.html') || window.location.pathname.includes('teacher-dashboard.html') || window.location.pathname.includes('edit-profile') || window.location.pathname.includes('change-password.html')) {
        showToast('يجب تسجيل الدخول للوصول إلى هذه الصفحة', 'danger');
        setTimeout(() => window.location.href = '../pages/login.html', 1500);
      }
    }, 100);
  }
});

// ==================== دالة تسجيل الخروج ====================
const logout = async () => {
  try {
    const user = auth.currentUser;
    if (user) {
      await setDoc(doc(db, 'notifications', `${user.uid}_${Date.now()}`), {
        userId: user.uid,
        type: 'logout',
        message: 'تم تسجيل الخروج بنجاح',
        timestamp: serverTimestamp()
      }, { merge: true });
    }
    
    await signOut(auth);
    localStorage.removeItem('userLoggedIn');
    localStorage.setItem('justLoggedOut', 'true');
    showToast('تم تسجيل الخروج بنجاح', 'success');
    setTimeout(() => window.location.href = '../pages/login.html', 1000);
  } catch (error) {
    console.error('Logout error:', error);
    const errorMessages = {
      'auth/network-request-failed': 'فشل الاتصال بالخادم، تحقق من اتصالك بالإنترنت',
      'auth/too-many-requests': 'تم تجاوز عدد المحاولات، يرجى المحاولة لاحقاً'
    };
    showToast(errorMessages[error.code] || `خطأ أثناء تسجيل الخروج: ${error.code} - ${error.message}`, 'danger');
  }
};

// ==================== إدارة تسجيل الدخول ====================
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = loginForm.loginEmail.value.trim();
    const password = loginForm.loginPassword.value;
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    
    if (!validateEmail(email)) {
      showToast('يرجى إدخال بريد إلكتروني صحيح', 'warning');
      return;
    }
    
    if (!validatePassword(password)) {
      showToast('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، بما في ذلك حرف كبير، حرف صغير، ورقم', 'warning');
      return;
    }
    
    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري المعالجة...';
      
      console.log('Attempting to sign in with email:', email);
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      if (!user.emailVerified) {
        await sendEmailVerification(user);
        await signOut(auth);
        showToast('يرجى التحقق من بريدك الإلكتروني أولاً', 'warning');
        return;
      }
      
      console.log('User signed in, checking userType');
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      let userType = 'parent';
      if (userDoc.exists()) {
        userType = userDoc.data().userType || 'parent';
        console.log('UserType from Firestore:', userType);
      } else {
        console.log('No user document found, defaulting to parent');
      }
      
      showToast('تم تسجيل الدخول بنجاح', 'success');
      
      const redirectUrl = userType === 'student' ? '../pages/student-dashboard.html' :
                         userType === 'parent' ? '../pages/parent-dashboard.html' :
                         userType === 'teacher' ? '../pages/teacher-dashboard.html' : '../pages/index.html';
      console.log('Redirecting to:', redirectUrl);
      window.location.href = redirectUrl;
      
    } catch (error) {
      console.error('Login error:', error);
      const errorMessages = {
        'auth/user-not-found': 'البريد الإلكتروني غير مسجل',
        'auth/wrong-password': 'كلمة المرور غير صحيحة',
        'auth/too-many-requests': 'تم تجاوز عدد المحاولات، يرجى المحاولة لاحقاً'
      };
      
      showToast(errorMessages[error.code] || `خطأ أثناء تسجيل الدخول: ${error.message}`, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'تسجيل الدخول';
    }
  });
};

// ==================== إدارة التسجيل ====================
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    console.log('Register form submitted');
    
    const formData = {
      userType: registerForm.userType.value,
      firstName: registerForm.regFirstName.value.trim(),
      lastName: registerForm.regLastName.value.trim(),
      birthDate: registerForm.regBirthDate.value,
      phone: registerForm.regPhone.value.trim(),
      state: registerForm.regState.value,
      delegation: registerForm.regDelegation.value,
      email: registerForm.regEmail.value.trim(),
      password: registerForm.regPassword.value
    };

    if (formData.userType === 'student') {
      formData.educationLevel = registerForm.educationLevel?.value || null;
      formData.academicYear = registerForm.academicYear?.value || null;
      formData.branch = registerForm.branch?.value || null;
      formData.electiveSubject = registerForm.electiveSubject?.value || null;
      formData.studentAverage = registerForm.studentAverage?.value || null;
      if (!formData.educationLevel) {
        showToast('يرجى اختيار المستوى الدراسي', 'warning');
        return;
      }
    }

    if (formData.userType === 'teacher') {
      formData.teacherEducationLevel = registerForm.teacherEducationLevel?.value || null;
      formData.teacherField = registerForm.teacherField?.value || null;
      formData.teacherSubject = registerForm.teacherSubject?.value || null;
      formData.additionalSubjects = Array.from(registerForm.querySelectorAll('select[name="additionalSubject"]'))
        .map(select => select.value)
        .filter(value => value);
      if (!formData.teacherEducationLevel) {
        showToast('يرجى اختيار المستوى الدراسي الذي تدرسه', 'warning');
        return;
      }
      if (!formData.teacherSubject && !formData.teacherField) {
        showToast('يرجى اختيار المادة أو المجال الذي تدرسه', 'warning');
        return;
      }
    }

    if (!formData.userType || !formData.firstName || !formData.lastName || !formData.birthDate || !formData.phone || !formData.state || !formData.delegation || !formData.email || !formData.password) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'warning');
      return;
    }

    if (!validateEmail(formData.email)) {
      showToast('يرجى إدخال بريد إلكتروني صحيح', 'warning');
      return;
    }

    if (!validatePassword(formData.password)) {
      showToast('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، بما في ذلك حرف كبير، حرف صغير، ورقم', 'warning');
      return;
    }

    if (formData.password !== registerForm.confirmPassword.value) {
      showToast('كلمة المرور وتأكيد كلمة المرور غير متطابقتين', 'warning');
      return;
    }

    try {
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري الإنشاء...';
      console.log('Attempting to create user with email:', formData.email);

      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);

      if (!['student', 'parent', 'teacher', 'admin'].includes(formData.userType)) {
        throw new Error('نوع المستخدم غير صالح');
      }

      await setDoc(doc(db, 'users', userCredential.user.uid), {
        ...formData,
        createdAt: serverTimestamp(),
        emailVerified: false,
        lastPasswordChange: serverTimestamp()
      });

      await sendEmailVerification(userCredential.user);
      showToast('تم إنشاء الحساب بنجاح! يرجى التحقق من بريدك', 'success');
      registerForm.reset();

      setTimeout(() => {
        redirectUserBasedOnType(userCredential.user);
      }, 2000);
    } catch (error) {
      console.error('Registration error:', error);
      const errorMessages = {
        'auth/email-already-in-use': 'البريد الإلكتروني مستخدم بالفعل',
        'auth/weak-password': 'كلمة المرور ضعيفة جداً',
        'auth/invalid-email': 'بريد إلكتروني غير صالح',
        'permission-denied': 'ليس لديك إذن لإنشاء هذا الحساب'
      };
      showToast(errorMessages[error.code] || `خطأ أثناء إنشاء الحساب: ${error.message}`, 'danger');
    } finally {
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      submitBtn.disabled = false;
      submitBtn.textContent = 'إنشاء حساب';
    }
  });
};

// ==================== إدارة إعادة تعيين كلمة المرور ====================
const resetPasswordForm = document.getElementById('resetPasswordForm');
if (resetPasswordForm) {
  resetPasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = resetPasswordForm.resetEmail.value.trim();
    const submitBtn = resetPasswordForm.querySelector('button[type="submit"]');
    
    if (!validateEmail(email)) {
      showToast('يرجى إدخال بريد إلكتروني صحيح', 'warning');
      return;
    }
    
    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري المعالجة...';
      
      await sendPasswordResetEmail(auth, email);
      showToast('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني', 'success');
      resetPasswordForm.reset();
      setTimeout(() => {
        window.location.href = '../pages/login.html';
      }, 2000);
    } catch (error) {
      console.error('Reset password error:', error);
      const errorMessages = {
        'auth/user-not-found': 'البريد الإلكتروني غير مسجل',
        'auth/invalid-email': 'بريد إلكتروني غير صالح',
        'auth/too-many-requests': 'تم تجاوز عدد المحاولات، يرجى المحاولة لاحقاً'
      };
      showToast(errorMessages[error.code] || `خطأ أثناء إعادة تعيين كلمة المرور: ${error.message}`, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'إعادة تعيين كلمة المرور';
    }
  });
};

// ==================== إدارة تغيير كلمة المرور ====================
const changePasswordForm = document.getElementById('changePasswordForm');
if (changePasswordForm) {
  const newPasswordInput = document.getElementById('newPassword');
  const passwordStrengthBar = document.getElementById('passwordStrength');
  const passwordStrengthText = document.getElementById('passwordStrengthText');
  
  if (newPasswordInput && passwordStrengthBar && passwordStrengthText) {
    newPasswordInput.addEventListener('input', () => {
      let strength = 0;
      if (newPasswordInput.value.length >= 8) strength++;
      if (/[A-Zا-ي]/.test(newPasswordInput.value)) strength++;
      if (/[a-zا-ي]/.test(newPasswordInput.value)) strength++;
      if (/[0-9]/.test(newPasswordInput.value)) strength++;
      
      passwordStrengthBar.className = 'password-strength';
      passwordStrengthText.textContent = '';
      
      if (newPasswordInput.value.length > 0) {
        if (strength <= 2) {
          passwordStrengthBar.classList.add('weak');
          passwordStrengthText.textContent = 'كلمة المرور ضعيفة';
        } else if (strength === 3) {
          passwordStrengthBar.classList.add('medium');
          passwordStrengthText.textContent = 'كلمة المرور متوسطة';
        } else {
          passwordStrengthBar.classList.add('strong');
          passwordStrengthText.textContent = 'كلمة المرور قوية';
        }
      }
    });
  }
  
  changePasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const currentPassword = changePasswordForm.currentPassword.value.trim();
    const newPassword = changePasswordForm.newPassword.value.trim();
    const confirmPassword = changePasswordForm.confirmPassword.value.trim();
    const submitBtn = changePasswordForm.querySelector('button[type="submit"]');
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      showToast('يرجى ملء جميع الحقول', 'warning');
      return;
    }
    
    if (!validatePassword(newPassword)) {
      showToast('كلمة المرور الجديدة يجب أن تحتوي على 8 أحرف على الأقل، بما في ذلك حرف كبير، حرف صغير، ورقم', 'warning');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      showToast('كلمة المرور الجديدة وتأكيدها غير متطابقتين', 'warning');
      return;
    }
    
    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري المعالجة...';
      
      const user = auth.currentUser;
      if (!user) {
        showToast('يجب تسجيل الدخول لتغيير كلمة المرور', 'danger');
        setTimeout(() => window.location.href = '../pages/login.html', 2000);
        return;
      }
      
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential).catch((error) => {
        if (error.code === 'auth/wrong-password') {
          throw new Error('auth/wrong-password');
        }
        throw error;
      });
      
      await updatePassword(user, newPassword);
      await updateDoc(doc(db, 'users', user.uid), {
        lastPasswordChange: serverTimestamp()
      });
      
      await setDoc(doc(db, 'notifications', `${user.uid}_${Date.now()}`), {
        userId: user.uid,
        type: 'password_change',
        message: 'تم تغيير كلمة المرور بنجاح',
        timestamp: serverTimestamp()
      });
      
      showToast('تم تغيير كلمة المرور بنجاح', 'success');
      changePasswordForm.reset();
      passwordStrengthBar.className = 'password-strength';
      passwordStrengthText.textContent = '';
      await redirectUserBasedOnType(user);
    } catch (error) {
      console.error('Change password error:', error);
      const errorMessages = {
        'auth/wrong-password': 'كلمة المرور الحالية غير صحيحة',
        'auth/requires-recent-login': 'يرجى تسجيل الدخول مرة أخرى لتغيير كلمة المرور',
        'auth/weak-password': 'كلمة المرور الجديدة ضعيفة جداً',
        'auth/too-many-requests': 'تم تجاوز عدد المحاولات، يرجى المحاولة لاحقاً'
      };
      showToast(errorMessages[error.code] || `خطأ أثناء تغيير كلمة المرور: ${error.message}`, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'تغيير كلمة المرور';
    }
  });
};

// ==================== إدارة تعديل الملف الشخصي ====================
const editProfileForm = document.getElementById('editProfileForm');
if (editProfileForm) {
  const avatarUpload = document.getElementById('avatarUpload');
  const avatarPreview = document.getElementById('avatarPreview');
  
  if (avatarUpload && avatarPreview) {
    avatarUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        if (!['image/png', 'image/jpeg'].includes(file.type)) {
          showToast('يرجى اختيار صورة بصيغة PNG أو JPEG', 'warning');
          avatarUpload.value = '';
          return;
        }
        if (file.size / 1024 / 1024 > 5) {
          showToast('حجم الصورة يجب أن لا يتجاوز 5 ميغابايت', 'warning');
          avatarUpload.value = '';
          return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
          avatarPreview.src = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    });
  }
  
  editProfileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const firstName = editProfileForm.editFirstName?.value.trim() || '';
    const lastName = editProfileForm.editLastName?.value.trim() || '';
    const phone = editProfileForm.editPhone?.value.trim() || '';
    const birthDate = editProfileForm.editBirthDate?.value || '';
    const state = editProfileForm.editState?.value || '';
    const delegation = editProfileForm.editDelegation?.value || '';
    const studentAverage = editProfileForm.editStudentAverage?.value || null;
    const avatarFile = avatarUpload?.files[0];
    const submitBtn = editProfileForm.querySelector('button[type="submit"]');
    
    if (phone && !/^[259][0-9]{7}$/.test(phone)) {
      showToast('رقم الهاتف يجب أن يكون 8 أرقام ويبدأ بـ 2 أو 5 أو 9', 'warning');
      return;
    }
    
    if (studentAverage && (studentAverage < 0 || studentAverage > 20)) {
      showToast('المعدل يجب أن يكون بين 0 و20', 'warning');
      return;
    }
    
    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري الحفظ...';
      
      const user = auth.currentUser;
      if (!user) {
        showToast('يجب تسجيل الدخول لتعديل الملف الشخصي', 'danger');
        setTimeout(() => window.location.href = '../pages/login.html', 2000);
        return;
      }
      
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (!userDoc.exists()) {
        showToast('لا يوجد ملف شخصي لهذا المستخدم', 'danger');
        return;
      }
      const userData = userDoc.data();
      
      const updatedData = {};
      if (firstName && firstName !== userData.firstName) updatedData.firstName = firstName;
      if (lastName && lastName !== userData.lastName) updatedData.lastName = lastName;
      if (phone && phone !== userData.phone) updatedData.phone = phone;
      if (birthDate && birthDate !== userData.birthDate) updatedData.birthDate = birthDate;
      if (state && state !== userData.state) updatedData.state = state;
      if (delegation && delegation !== userData.delegation) updatedData.delegation = delegation;
      if (studentAverage && studentAverage !== userData.studentAverage) updatedData.studentAverage = studentAverage;

      if (userData.userType === 'teacher') {
        const teacherEducationLevel = editProfileForm.teacherEducationLevel?.value || null;
        const teacherField = editProfileForm.teacherField?.value || null;
        const teacherSubject = editProfileForm.teacherSubject?.value || null;
        const additionalSubjects = Array.from(editProfileForm.querySelectorAll('select[name="additionalSubject"]'))
          .map(select => select.value)
          .filter(value => value);
        
        if (teacherEducationLevel && teacherEducationLevel !== userData.teacherEducationLevel) {
          updatedData.teacherEducationLevel = teacherEducationLevel;
        }
        if (teacherField && teacherField !== userData.teacherField) {
          updatedData.teacherField = teacherField;
        }
        if (teacherSubject && teacherSubject !== userData.teacherSubject) {
          updatedData.teacherSubject = teacherSubject;
        }
        if (additionalSubjects.length > 0 && JSON.stringify(additionalSubjects) !== JSON.stringify(userData.additionalSubjects || [])) {
          updatedData.additionalSubjects = additionalSubjects;
        }
      }

      if (avatarFile) {
        const storageRef = ref(storage, `avatars/${user.uid}/${avatarFile.name}`);
        await uploadBytes(storageRef, avatarFile);
        updatedData.avatarUrl = await getDownloadURL(storageRef);
      }

      if (Object.keys(updatedData).length > 0) {
        console.log('Updating Firestore with data:', updatedData);
        await updateDoc(doc(db, 'users', user.uid), updatedData);
        await setDoc(doc(db, 'notifications', `${user.uid}_${Date.now()}`), {
          userId: user.uid,
          type: 'profile_update',
          message: 'تم تحديث الملف الشخصي بنجاح',
          timestamp: serverTimestamp()
        });
        showToast('تم تحديث الملف الشخصي بنجاح', 'success');
        await loadUserProfile(user); // إعادة تحميل البيانات لتحديث الواجهة
      } else {
        showToast('لم يتم إجراء أي تغييرات', 'info');
      }
      
      await redirectUserBasedOnType(user);
    } catch (error) {
      console.error('Error updating profile:', error);
      const errorMessages = {
        'permission-denied': 'ليس لديك إذن لتحديث الملف الشخصي',
        'unavailable': 'خدمة Firestore غير متاحة، تحقق من اتصالك بالإنترنت',
        'unauthenticated': 'يرجى تسجيل الدخول مرة أخرى'
      };
      showToast(errorMessages[error.code] || `خطأ أثناء تحديث الملف الشخصي: ${error.code} - ${error.message}`, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'حفظ التغييرات';
    }
  });
};

// ==================== تهيئة الصفحة ====================
document.addEventListener('DOMContentLoaded', () => {
  const currentPath = window.location.pathname.split('/').pop();
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    if (link.getAttribute('href') === currentPath || link.getAttribute('href') === `../pages/${currentPath}`) {
      link.classList.add('active');
    }
  });
  
  if (typeof bootstrap !== 'undefined') {
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    [...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));
  }
  
  document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', () => {
      const input = button.nextElementSibling;
      if (input && input.tagName === 'INPUT') {
        const icon = button.querySelector('i');
        input.type = input.type === 'password' ? 'text' : 'password';
        icon.classList.toggle('fa-eye-slash');
        icon.classList.toggle('fa-eye');
      } else {
        console.warn('No input field found next to toggle-password button');
      }
    });
  });

  document.querySelectorAll('.logout-btn').forEach(button => {
    button.addEventListener('click', () => {
      logout();
    });
  });
});

// تصدير الدوال المستخدمة في صفحات أخرى
export { 
  auth, 
  db, 
  storage, 
  getAuth, 
  getFirestore, 
  getDoc, 
  doc, 
  updateDoc, 
  signOut, 
  showToast, 
  logout, 
  loadUserProfile, 
  onAuthStateChanged, 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  sendPasswordResetEmail, 
  sendEmailVerification, 
  updatePassword, 
  reauthenticateWithCredential, 
  EmailAuthProvider 
};