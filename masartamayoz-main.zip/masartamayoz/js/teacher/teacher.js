import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js';
import { getFirestore, doc, getDoc, collection, getDocs, query, where, addDoc } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js';
import Chart from 'https://cdn.jsdelivr.net/npm/chart.js';

const auth = getAuth();
const db = getFirestore();

const teacherName = document.getElementById('teacherName');
const teacherEmail = document.getElementById('teacherEmail');
const studentCount = document.getElementById('studentCount');
const studentsChart = document.getElementById('studentsChart').getContext('2d');
const userAvatar = document.getElementById('userAvatar');
const logoutBtn = document.getElementById('logoutBtn');
const scheduleLesson = document.getElementById('scheduleLesson');
const scheduledLessons = document.getElementById('scheduledLessons');

let chart = new Chart(studentsChart, {
  type: 'pie',
  data: { labels: [], datasets: [{ data: [], backgroundColor: ['#FF6384', '#36A2EB'] }] },
  options: { responsive: true }
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists() && userDoc.data().userType === 'teacher') {
      const userData = userDoc.data();
      teacherName.textContent = userData.name || 'غير محدد';
      teacherEmail.textContent = user.email || 'غير محدد';
      const courses = await getDocs(query(collection(db, 'courses'), where('teacher', '==', user.uid)));
      let totalStudents = 0;
      const studentCounts = [];
      courses.forEach(doc => {
        const data = doc.data();
        totalStudents += data.students?.length || 0;
        studentCounts.push(data.students?.length || 0);
      });
      studentCount.textContent = totalStudents;
      chart.data.labels = courses.docs.map(d => d.data().subject || `دورة ${d.id}`);
      chart.data.datasets[0].data = studentCounts;
      chart.update();
      userAvatar.textContent = userData.name?.charAt(0) || user.email.charAt(0);

      scheduledLessons.innerHTML = courses.docs.map(doc => `<p>${doc.data().subject} - <a href="${doc.data().meetLink}" target="_blank">انضم</a></p>`).join('');
    } else window.location.href = '../index.html';
  } else window.location.href = '../login.html';
});

scheduleLesson.addEventListener('click', () => {
  const specialty = prompt('أدخل التخصص');
  if (specialty && auth.currentUser) {
    const meetLink = `https://meet.google.com/new?specialty=${specialty}`;
    addDoc(collection(db, 'courses'), { subject: specialty, teacher: auth.currentUser.uid, meetLink, scheduledAt: new Date() })
      .then(() => alert('تم جدولة الدرس!'));
  }
});

logoutBtn.addEventListener('click', () => signOut(auth).then(() => window.location.href = '../login.html'));